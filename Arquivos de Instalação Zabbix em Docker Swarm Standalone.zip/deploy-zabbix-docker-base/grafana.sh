mkdir -p /mnt/data-docker/grafana/data && \
chown -R 472:472 /mnt/data-docker/grafana/data && \
chmod -R 775 /mnt/data-docker/grafana && mkdir -p /mnt/data-docker/grafana/certs && \
chown -R 472:472 /mnt/data-docker/grafana/certs